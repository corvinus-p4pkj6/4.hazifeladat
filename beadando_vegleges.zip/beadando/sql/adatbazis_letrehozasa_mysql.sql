DROP DATABASE IF EXISTS `beadando_feladat`;
CREATE DATABASE  IF NOT EXISTS `beadando_feladat`;
USE `beadando_feladat`;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `felhasznalok`;

CREATE TABLE `felhasznalok` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `felhasznalonev` varchar(128) DEFAULT NULL,
  `valodi_nev` varchar(128) DEFAULT NULL,
  `jelszo` varchar(128) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;
