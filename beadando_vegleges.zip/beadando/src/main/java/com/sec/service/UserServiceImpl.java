package com.sec.service;

import com.sec.entity.User;
import com.sec.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.regex.Pattern;

@Service
public class UserServiceImpl implements UserService, UserDetailsService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Autowired
    public UserServiceImpl(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username);
        if (user == null) {
            throw new UsernameNotFoundException(username);
        }

        return new UserDetailsImpl(user);
    }

    @Override
    public String registerUser(User userToRegister) {
        User userCheck = userRepository.findByUsername(userToRegister.getUsername());

        if (userCheck != null) {
            return "Már létezik ilyen felhasználó!";
        }

        if (userToRegister.getUsername().length() < 6) {
            return "A felhasználónévnek legalább 6 karakterből kell állnia!";
        }

        Pattern betutTartalmaz = Pattern.compile(".*[a-zA-Z].*");
        Pattern szamotTartalmaz = Pattern.compile(".*[0-9].*");
        if (!betutTartalmaz.matcher(userToRegister.getPassword()).matches() || !szamotTartalmaz.matcher(userToRegister.getPassword()).matches()) {
            return "A jelszónak legalább egy betűt és egy számot is tartalmaznia kell!";
        }

        if (userToRegister.getPassword().length() < 8) {
            return "A jelszónak legalább 8 karakterből kell állnia!";
        }

        userToRegister.setPassword(passwordEncoder.encode(userToRegister.getPassword()));

        userRepository.save(userToRegister);

        return "ok";
    }


}
