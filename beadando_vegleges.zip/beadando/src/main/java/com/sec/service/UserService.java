package com.sec.service;

import com.sec.entity.User;

public interface UserService {

    String registerUser(User user);

}
